package hello;

public class AddBinary {
	
	
	public static void  addBinary(String a, String b) {
		String res="a";
		int max=0;
		int c=0;
		int d=0;//��������ĳ��Ȳ��
		if(a.length()>b.length()){
			max=a.length();
			d=max-b.length();}
			else {
				max=b.length();
				d=max-a.length();
		}

		char []m=new char[max];
		char []n=new char[max];
		char []r=new char[max+1];
		m=a.toCharArray();
		n=b.toCharArray();
		//�˴����Ǹ���������д�����ǰ��̵Ĳ���Ҫ������
		if (a.length()>b.length()) {
			//��bǰ��
			for(int i=b.length()-1,j=max-1;i>0;i--,j--){
				n[j]=n[i];
			}
			for (int i = 0; i <d-1; i++) {
				n[i]=0;
			}
		}
		else {
			//��aǰ��
			
		}
		for (int i = max-1; i >0; i--) {
			if ((m[i]==0)&&(n[i]==0)&&(c==0)) {
				r[i]=0;
				c=0;
			}
			else if (m[i]==1&&n[i]==0&&c==0) {
				r[i]=1;
				c=0;
			}
			else if (m[i]==0&&n[i]==1&&c==0) {
				r[i]=1;
				c=0;
			}
			else if (m[i]==0&&n[i]==0&&c==1) {
				r[i]=1;
				c=0;
			}
			else if (m[i]==1&&n[i]==1&&c==0) {
				r[i]=0;
				c=1;
			}
			else if (m[i]==1&&n[i]==0&&c==1) {
				r[i]=0;
				c=1;
			}
			else if (m[i]==0&&n[i]==1&&c==1) {
				r[i]=0;
				c=1;
			}
			else {
				r[i]=1;
				c=1;
			}
		}


		if (c==1) {
			r[0]=1;
			for (int i = 0; i < r.length; i++) {
				System.out.print(r[i]);
			}
		}else {
			r[0]=0;
			for (int i = 1; i < r.length; i++) {
				System.out.print(r[i]);
			}
		}
		
		
		
		return res;
		
		
		
		
		//���������ˣ�ת����int��Խ�簡��������ʵ���������
		/**String s=a;
		int m=0;
		int n=0;	
		m=Integer.valueOf(a, 2);
		n=Integer.valueOf(b, 2);		
		int sum=m+n;
		s=Integer.toBinaryString(sum);
		System.out.print(s);
		return s;*/
	    
	}
    
    public static void main(String[] args) {
    	String s="a";
    	addBinary("11", "1");
    }
}

